package com.almela.gaetan.chromatilt;

import android.content.Context;
import android.opengl.GLSurfaceView;

/**
 * Created by Willg on 1/4/2018.
 */

public class FilterGLSurfaceView extends GLSurfaceView {

    public FilterGLSurfaceView(Context context) {
        super(context);
    }
}
